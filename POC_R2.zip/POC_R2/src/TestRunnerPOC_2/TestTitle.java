package TestRunnerPOC_2;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import ExcelOperations.excel_operations;
import PageObjectModel_POC2.AuthenticationPage;
import PageObjectModel_POC2.HomePage;
import PageObjectModel_POC2.MyAccount;
import PageObjectModel_POC2.testData;
import Presentation.Lined;

public class TestTitle 
{
WebDriver driver;
HomePage hp_poc_2;
Logger log;
AuthenticationPage ap_poc_2;
	List<testData> testdatas=new ArrayList<>();
	@BeforeClass
	public void initSetup() 
	{
	    for(int i=1;i<4;i++) 
	    { 
		testdatas.add(excel_operations.readExcel(i));
		
	
		
	    }
	    
	}

	


   @BeforeClass
   public void beforeM() 
   {
	   System.setProperty("webdriver.chrome.driver","C:\\Users\\anmol.srivastava\\Desktop\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://automationpractice.com/index.php");
		hp_poc_2=new HomePage(driver);
		
   }
  
   @Test(priority=0)
   public void verifyHomePageTitle() 
   {
	
	   
	   HomePage hp_poc_2=new HomePage(driver);
	   
	   String actualHomePageTitle=hp_poc_2.getTitle();
	   String expectedHomePageTitle="My Store";
	   log=Logger.getLogger("devpinoyLogger");
	   log.info("Home Page Title Verification Started");
	   log.info("Expected: "+expectedHomePageTitle+" Actual: "+actualHomePageTitle);
	   log.info(Lined.upperLowerBorder());
	   SoftAssert sa=new SoftAssert();
	   sa.assertEquals(actualHomePageTitle,expectedHomePageTitle);
	   sa.assertAll();
	   
	   log.info(Lined.middleBorder()+"Home Page Title displayed correctly"+Lined.middleBorder());
	   
	   log.info(Lined.upperLowerBorder());
   
   }
   @Test(priority=2)
   public void signInLink()
   {
	   
	  
	  
	  
	   String expectedSignInLinkText="Sign in";
	   String actualSignInLinkText=hp_poc_2.getSignInLinkText();
	   log=Logger.getLogger("devpinoyLogger");
	   log.info("Verfication for signIn Text Started");
	   log.info("Expected: "+expectedSignInLinkText+" Actual: "+actualSignInLinkText);
	   log.info(Lined.upperLowerBorder());
	   SoftAssert sa=new SoftAssert();
	   sa.assertEquals(actualSignInLinkText,expectedSignInLinkText);
	 
	   sa.assertAll();
	   hp_poc_2.clickSignIn();
	   Wait wait=new WebDriverWait(driver,20); 
	   wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='email']")));
	  
	   log.info(Lined.middleBorder()+"signInLink displayed correctly"+Lined.middleBorder());
	 
	   log.info(Lined.upperLowerBorder());
   }
   @Test(priority=3)
   public void verifyAuthenticationPageTitle()
   {
	   ap_poc_2=new AuthenticationPage(driver);
	   String actualAuthenticationPageTitle =ap_poc_2.getTitle();
	   System.out.println(actualAuthenticationPageTitle);
	   String expectedAuthenticationPageTitle="Login - My Store";
	   log=Logger.getLogger("devpinoyLogger");
	   log.info("Verification for authentication page title started");
	   log.info("Expected: "+expectedAuthenticationPageTitle+" Actual: "+actualAuthenticationPageTitle);
	   log.info(Lined.upperLowerBorder());
	   SoftAssert sa=new SoftAssert();
	   sa.assertEquals(actualAuthenticationPageTitle,expectedAuthenticationPageTitle);
	   sa.assertAll();
	  
	   log.info(Lined.middleBorder()+"Authentication PAge Title displayed correctly"+Lined.middleBorder());
	   
	   log.info(Lined.upperLowerBorder());
	   
	  
   }
  
	  

  
  
}
