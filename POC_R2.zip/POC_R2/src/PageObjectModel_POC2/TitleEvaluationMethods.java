package PageObjectModel_POC2;

import org.openqa.selenium.WebDriver;

public class TitleEvaluationMethods 
{
	WebDriver driver;
	public TitleEvaluationMethods (WebDriver driver) 
	{
		this.driver=driver;
	}
	
	public String getTitle() 
	{
		return driver.getTitle();
	}
	
	
	
	
	public boolean evaluateTestResult(String Expected,String Actual) 
	{
	
	
	if(Expected.contentEquals(Actual)) 
	{
		return true;
	}	
	else 
	{
		return false;
	}
		
	}

}
