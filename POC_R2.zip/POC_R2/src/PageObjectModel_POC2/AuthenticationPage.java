package PageObjectModel_POC2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class AuthenticationPage extends TitleEvaluationMethods
{
	WebDriver driver;
    @FindBy(how=How.ID,using="email")
    WebElement emailTextBar;
    @FindBy(how=How.ID,using="passwd")
    WebElement passwordTextBar;
    @FindBy(how=How.ID,using="SubmitLogin")
    WebElement loginButton;
    public AuthenticationPage(WebDriver driver) 
    {
    	super(driver);
    	this.driver=driver;
    	PageFactory.initElements(driver, this);
    }
	
	
	
	
	public void enterEmailId(String emailId) 
	{
		emailTextBar.sendKeys(emailId);
	}
	public void enterPassword(String password) 
	{
		passwordTextBar.sendKeys(password);
	}
	public void clickSignInButton() 
	{
		loginButton.click();
	}
	public void doLogin(String email,String password ) 
	{
		enterEmailId(email);
		enterPassword(password);
		clickSignInButton();
	}

}
