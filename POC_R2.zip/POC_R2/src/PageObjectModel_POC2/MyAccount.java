package PageObjectModel_POC2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class MyAccount extends TitleEvaluationMethods
{
	WebDriver dr;
	@FindBy(how=How.XPATH,using="//a[@class='account']")
	WebElement myAccountName;
	@FindBy(how=How.XPATH,using="//a[@class='logout']")
	WebElement logoutLink;
	public MyAccount(WebDriver driver) 
	{
		super(driver);
		this.dr=driver;
		PageFactory.initElements(driver,this);
		
	}
	
	public String  getMyAccountName() 
	{
		
		return myAccountName.getText();
		
	}
	
	public void logout() 
	{
		
		logoutLink.click();
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
